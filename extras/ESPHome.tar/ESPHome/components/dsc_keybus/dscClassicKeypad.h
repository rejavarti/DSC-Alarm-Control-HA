#ifndef dscClassicKeypad_h
#define dscClassicKeypad_h

#include "dsc_common_constants.h"

class dscClassicKeypadInterface {

  public:
    dscClassicKeypadInterface(byte setClockPin, byte setReadPin, byte setWritePin);

    // Interface control
    void begin(Stream &_stream = Serial);                            // Initializes the stream output to Serial by default
    bool loop();                                                     // Returns true if valid panel data is available
    void stop();                                                     // Stops the keypad interface
    void beep(byte beeps = 0);                                       // Keypad beep, 1-128 beeps
    void tone(byte beep = 0, bool tone = false, byte interval = 0);  // Keypad tone pattern, 1-7 beeps at 1-15s interval, with optional constant tone
    void buzzer(byte seconds = 0);                                   // Keypad buzzer, 1-255 seconds

    // Keypad key
    byte key, keyAvailable;

    // Keypad lights
    Light lightReady = on, lightArmed, lightMemory, lightBypass, lightTrouble, lightProgram, lightFire, lightBacklight = on;
    Light lightZone1, lightZone2, lightZone3, lightZone4, lightZone5, lightZone6, lightZone7, lightZone8;

    // Panel Keybus commands
    byte classicCommand[2]  = {0x00, 0x80};

    static volatile byte moduleData[dscReadSize];
    static volatile bool bufferOverflow;

    // Timer interrupt function to capture data - declared as public for use by AVR Timer1
    static void dscClockInterrupt();

  private:
    void zoneLight(Light lightZone, byte zoneBit);
    void panelLight(Light lightPanel, byte zoneBit);

    Stream* stream;
    byte panelLights = 0x80, previousLights = 0x80;
    byte panelBlink, previousBlink;
    byte panelZones, previousZones;
    byte panelZonesBlink, previousZonesBlink;
    bool startupCycle = true;
    bool setBeep, setTone, setBuzzer;
    byte commandInterval = 26;   // Sets the milliseconds between panel commands
    bool keyBeep, beepStart;

    static int clockInterval;
    static byte dscClockPin;
    static byte dscReadPin;
    static byte dscWritePin;
    static volatile byte keyData;
    static volatile byte keyBufferLength;
    static volatile byte keyBuffer[dscBufferSize];
    static volatile bool commandReady, moduleDataDetected;
    static volatile bool alarmKeyDetected, alarmKeyResponsePending;
    static volatile byte clockCycleCount, clockCycleTotal;
    static volatile byte panelCommand[dscReadSize], panelCommandByteCount, panelCommandByteTotal;
    static volatile byte isrPanelBitTotal, isrPanelBitCount;
    static volatile byte isrModuleData[dscReadSize], isrModuleBitTotal, isrModuleBitCount, isrModuleByteCount;
    static volatile unsigned long intervalStart, beepInterval, repeatInterval, keyInterval, alarmKeyTime, alarmKeyInterval;
    static volatile bool moduleDataCaptured;
    static volatile byte moduleByteCount;
    static volatile byte moduleBitCount;

#if defined(ESP32) || defined(ESP_PLATFORM)
    static hw_timer_t * timer1;
    static portMUX_TYPE timer1Mux;
    
    // Additional ESP32 safety variables to prevent LoadProhibited crashes
    static volatile bool esp32_hardware_initialized;
    static volatile bool esp32_timers_configured;
    static volatile unsigned long esp32_init_timestamp;
#endif
};

#endif // dscClassicKeypad_h
